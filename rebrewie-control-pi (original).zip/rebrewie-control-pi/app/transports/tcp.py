"""
app/transports/tcp.py – raw line-oriented TCP transport.

The Brewie machine listens on a TCP socket (default port 8332).
Commands are sent as newline-terminated UTF-8 strings.
Responses are similarly newline-terminated lines.
"""
from __future__ import annotations

import asyncio
import time
from typing import AsyncIterator

from .base import BaseTransport
from ..config import settings
from ..state import brew_state


class TcpTransport(BaseTransport):
    def __init__(self) -> None:
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._connected = False

    async def connect(self) -> None:
        try:
            self._reader, self._writer = await asyncio.wait_for(
                asyncio.open_connection(settings.brewie_host, settings.brewie_port),
                timeout=10.0,
            )
            self._connected = True
            brew_state.connected = True
            brew_state.transport_type = "tcp"
            brew_state.add_log(
                f"TCP connected to {settings.brewie_host}:{settings.brewie_port}"
            )
        except (OSError, asyncio.TimeoutError) as exc:
            brew_state.connected = False
            brew_state.add_log(f"TCP connect failed: {exc}")
            raise

    async def disconnect(self) -> None:
        self._connected = False
        if self._writer:
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:
                pass
        brew_state.connected = False
        brew_state.add_log("TCP disconnected")

    async def send(self, command: str) -> None:
        if not self._writer:
            raise RuntimeError("TCP not connected")
        line = command.strip() + "\n"
        self._writer.write(line.encode("utf-8"))
        await self._writer.drain()
        brew_state.add_log(f"→ {command}")

    async def receive(self) -> AsyncIterator[str]:
        if not self._reader:
            return
        while self._connected:
            try:
                raw = await asyncio.wait_for(self._reader.readline(), timeout=5.0)
                if not raw:
                    brew_state.add_log("TCP connection closed by remote")
                    self._connected = False
                    brew_state.connected = False
                    break
                line = raw.decode("utf-8", errors="replace").strip()
                if line:
                    brew_state.last_raw = line
                    brew_state.last_updated = time.time()
                    brew_state.add_log(f"← {line}")
                    yield line
            except asyncio.TimeoutError:
                # No data – send a heartbeat so the OS detects dropped conn
                try:
                    await self.send("P80")
                except Exception:
                    break
            except Exception as exc:
                brew_state.add_log(f"TCP receive error: {exc}")
                self._connected = False
                brew_state.connected = False
                break
