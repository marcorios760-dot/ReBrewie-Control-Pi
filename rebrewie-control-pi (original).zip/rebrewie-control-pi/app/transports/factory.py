"""
app/transports/factory.py – return the configured transport instance.
"""
from __future__ import annotations

from ..config import settings
from .base import BaseTransport


def get_transport() -> BaseTransport:
    t = settings.brewie_transport.lower()
    if t == "tcp":
        from .tcp import TcpTransport
        return TcpTransport()
    if t == "serial":
        from .serial_transport import SerialTransport
        return SerialTransport()
    if t == "http":
        from .http_transport import HttpTransport
        return HttpTransport()
    # Default: mock
    from .mock import MockTransport
    return MockTransport()
