"""
app/transports/http_transport.py – HTTP/JSON bridge transport.

Some ReBrewie firmware builds expose an HTTP endpoint for command
injection.  This transport wraps that REST bridge using httpx.
"""
from __future__ import annotations

import asyncio
import time
from typing import AsyncIterator

import httpx

from .base import BaseTransport
from ..config import settings
from ..state import brew_state


class HttpTransport(BaseTransport):
    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._connected = False
        self._poll_queue: asyncio.Queue[str] = asyncio.Queue()
        self._poll_task: asyncio.Task | None = None

    async def connect(self) -> None:
        self._client = httpx.AsyncClient(
            base_url=settings.brewie_http_base, timeout=10.0
        )
        self._connected = True
        brew_state.connected = True
        brew_state.transport_type = "http"
        brew_state.add_log(f"HTTP transport connected to {settings.brewie_http_base}")
        self._poll_task = asyncio.create_task(self._poll_loop())

    async def disconnect(self) -> None:
        self._connected = False
        if self._poll_task:
            self._poll_task.cancel()
        if self._client:
            await self._client.aclose()
        brew_state.connected = False
        brew_state.add_log("HTTP transport disconnected")

    async def send(self, command: str) -> None:
        if not self._client:
            raise RuntimeError("HTTP transport not connected")
        try:
            resp = await self._client.post("/command", json={"cmd": command})
            resp.raise_for_status()
            brew_state.add_log(f"→ {command} ({resp.status_code})")
        except Exception as exc:
            brew_state.add_log(f"HTTP send error: {exc}")

    async def receive(self) -> AsyncIterator[str]:
        while self._connected:
            try:
                line = await asyncio.wait_for(self._poll_queue.get(), timeout=2.0)
                yield line
            except asyncio.TimeoutError:
                continue

    async def _poll_loop(self) -> None:
        """Poll /status every 2 seconds and push results to the queue."""
        while self._connected and self._client:
            await asyncio.sleep(2.0)
            try:
                resp = await self._client.get("/status")
                resp.raise_for_status()
                data = resp.json()
                # Accept both a flat string or a JSON object
                if isinstance(data, str):
                    line = data
                else:
                    line = " ".join(f"{k}={v}" for k, v in data.items())
                brew_state.last_raw = line
                brew_state.last_updated = time.time()
                await self._poll_queue.put(line)
            except Exception as exc:
                brew_state.add_log(f"HTTP poll error: {exc}")
